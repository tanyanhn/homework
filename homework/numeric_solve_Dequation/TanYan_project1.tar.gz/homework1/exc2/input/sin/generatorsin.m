clear

t = [128 256 512 1024];
dim = 1;
name = "../input/sin";
filename = "../allinput.txt";

for i = 1:4
    n = t(i);
    x = 0:1/n:1;
    v = x .* 0;
    v(1) = sin(0);
    v(n+1) = sin(1*pi);
    aim = sin(x .* pi);
    f = pi * pi * sin(x .* pi);
    
    dlmwrite("1/" + num2str(n) + "/v.txt", v, 'delimiter', '\n','precision', 14,'newline', 'pc');
    dlmwrite("1/" + num2str(n) + "/f.txt", f, 'delimiter', '\n','precision', 14,'newline', 'pc');
    dlmwrite("1/" + num2str(n) + "/aim.txt", aim, 'delimiter', '\n','precision', 14,'newline', 'pc');
    
    s = [name + "/" + num2str(dim) + "/"  + num2str(n) + "/aim.txt", 
        name + "/" + num2str(dim) + "/" + num2str(n) + "/input.txt"];
    id = fopen(filename,'a');
    fprintf(id,"%s  %s \n",s(1), s(2));
    fclose(id);
end
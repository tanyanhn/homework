#ifndef RELAX_TY
#define RELAX_TY

#include "equationsolver.h"

namespace solver_ty{

template<int dim, relax_type rtype>
class relax  {
  public:
    relax(){}
    
    ~relax(){}
};



}

#endif
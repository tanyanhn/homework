#ifndef REAL
#define REAL

typedef double Real;

#endif
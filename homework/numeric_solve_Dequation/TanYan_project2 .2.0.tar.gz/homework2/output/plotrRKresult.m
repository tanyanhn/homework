close all

addpath Runge-Kutta/

lw = 2;

right1 = dlmread("1right.txt");
right2 = dlmread("2right.txt");

mEuler1 = dlmread("modifyEuler1.txt");
mEuler2 = dlmread("modifyEuler2.txt");
iEuler1 = dlmread("improveEuler1.txt");
iEuler2 = dlmread("improveEuler2.txt");
RK1 = dlmread("classicalRK1.txt");
RK2 = dlmread("classicalRK2.txt");


figure(1)
subplot(3,1,1);
plot(mEuler1(:,1), mEuler1(:,2),'y','LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("modified Euler");

subplot(3,1,2);
plot(iEuler1(:,1), iEuler1(:,2),'y','LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("improved Euler");

subplot(3,1,3);
plot(RK1(:,1), RK1(:,2),'y','LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("classical Runge-Kutta");


figure(2)
subplot(3,1,1);
plot(mEuler2(:,1), mEuler2(:,2),'y','LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("modified Euler");

subplot(3,1,2);
plot(iEuler2(:,1), iEuler2(:,2),'y','LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("improved Euler");

subplot(3,1,3);
plot(RK2(:,1), RK2(:,2),'y','LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("classical Runge-Kutta");



close all

addpath A-Bashforth/

c = 'g';
lw = 2;

right1 = dlmread("1right.txt");
right2 = dlmread("2right.txt");

p11 = dlmread("p1init1.txt");
p12 = dlmread("p1init2.txt");
p21 = dlmread("p2init1.txt");
p22 = dlmread("p2init2.txt");
p31 = dlmread("p3init1.txt");
p32 = dlmread("p3init2.txt");
p41 = dlmread("p4init1.txt");
p42 = dlmread("p4init2.txt");



figure(1)
subplot(2,2,1);
plot(p11(:,1), p11(:,2),c,'LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 1");

subplot(2,2,2);
plot(p21(:,1), p21(:,2),c,'LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 2");

subplot(2,2,3);
plot(p31(:,1), p31(:,2),c,'LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 3");


subplot(2,2,4);
plot(p41(:,1), p41(:,2),c,'LineWidth',lw);hold on;
plot(right1(:,1), right1(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 4");


figure(2)
subplot(2,2,1);
plot(p12(:,1), p12(:,2),c,'LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 1");

subplot(2,2,2);
plot(p22(:,1), p22(:,2),c,'LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 2");

subplot(2,2,3);
plot(p32(:,1), p32(:,2),c,'LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 3");


subplot(2,2,4);
plot(p42(:,1), p42(:,2),c,'LineWidth',lw);hold on;
plot(right2(:,1), right2(:,2),'r');
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
title("p = 4");
